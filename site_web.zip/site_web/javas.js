// // // // let x = 5;
// // // // let y = 4;
// // // // let z = x+y;

// // // // // or 
// // // // // let z;
// // // // // // //

// // // // // z=x+y;

// // // // console.log(z);

// // // // alert(z);
// // // //  let name = "melya";
// // // //  let y = 5.4;

// // // // let arr = ["h","b","z"]; tableau
// // // // arr [2];
// // // // >>z

// // // // Object
// // // // let content = "coffee";
// // // // let goblet = {
// // // //     content:"coffee",
// // // //     hieght:20,
// // // //     window:10,
// // // //     weight: this.hieght+ this.width

// // // // }

// // // // console.log("function: ")

// // // // let a=5;
// // // // let b = 6 ;

// // // // calcul(a,b);
// // // // console.log("finished");

// // // // function calcul(a ,b ){
// // // //     let r = a + n ;
// // // //     console.log(r);

// // // // } pour laffichage ////////////////////////////


// // // // pour le retourn de resultat////////////////////////////
// // // // console.log("function: ")

// // // // // let a=5;
// // // // // let b = 6 ;

// // // // let add= calcul(5+6)/////////////////////// le resultat de return saffiche dans add ///// means calcul(r)////////////////

// // // // // // consol.log (add);/////////////////// affichage 
// // // // // // console.log("finished"); //////////////affichage 

// // // // // // function calcul(a ,b ){
// // // // // //     let r = a + b;
// // // //         return;///////////////////// le resulatat s'affiche dans la variable add ////////////////////////////
// // // // }


// // // //exemple////
// // // ////////////2 eme methode///////////////

// // // // console.log(subtruction (a,b))
// // // // console.log("finished")
// // // // function subtruction(a,b){
// // // //     return a-b;
// // // // }

// // // //   let x = 5;
// // // // let y = 4;
// // // // let z = x+y;

// // // // console.log(z);

// // // // alert(z);
// // // // document.getElementById("").innerHTML ????????????????/


// // // /////////////methodessss////////

// // // // let namee = "melya";
// // // // console.log("namee");
// // // // console.log(namee.toUpperCase())



// // // /////////object////////////object///////
// // // // let episode ={
// // // //     title:"sara",
// // // //      duration:30,
// // // //       hasbeenwatshed:"yes,no"}; 

// // // //       let hous = episode.duration; /////////// to get inside the object and pull the information ////////

// // // // let hour = "title"; //////secode methode to get information outside the object /////////////////////////////////////////
// // // // let herere = episode[hour];

// // // ///// text. splite// check it ////////////////////////////////


// // // ///////////////////les classes et constroctoret new to create an instance///////////////////////////


// // // // class Book {
// // // //     constructor(title, author, pages) {
// // // //         this.title = title;
// // // //         this.author = author;
// // // //         this.pages = pages;
// // //     // }
// // //     // Ici, le mot clé   this  fait référence à la nouvelle instance. Donc, 
// // //     // il utilise la notation dot pour attribuer les valeurs reçues aux clés correspondantes.


// // // // }

// // // // // Maintenant que la classe est terminée, vous pouvez créer des instances par le mot clé   new
// // // // let myBook = new Book("L'Histoire de Tao", "Will Alexander", 250);
// // // // //Cette ligne crée l'objet suivant :
// // // // {
// // // //         title: "L'Histoire de Tao",
// // // //         author: "Will Alexander",
// // // //         pages: 250
// // // // }

// // // // let guests = ["Will Alexander", "Sarah Kate", "Audrey Simon"];
// // // // let howManyGuests = guests.length; // 3

// // // // guests.push("Tao Perkington"); // ajoute "Tao Perkington" à la fin de notre tableau guests

// // // // guests.unshift("Tao Perkington"); // "Tao Perkington" est ajouté au début du tableau guests

// // // // guests.pop(); // supprimer le dernier élément du tableau////////////

// // // ///condition if ,,else ///////////////////////////////////

// // // let loguser = true;
// // // if (loguser){
// // //     console.log('vous etes =connectee..');

// // // } else {
// // //     console.log(" vous etes un intrus.....");
// // // }


// // // const numberOfSeats = 30;
// // // const numberOfGuests = 25;
// // // if (numberOfGuests < numberOfSeats) {
// // // // autoriser plus d'invités
// // // } else {
// // // // ne pas autoriser de nouveaux invités
// // // }


// // // let userLoggedIn = true;
// // // let UserHasPremiumAccount = true;
// // // let userHasMegaPremiumAccount = false;

// // // userLoggedIn && userHasPremiumAccount; // true
// // // userLoggedIn && userHasMegaPremiumAccount; // false

// // // userLoggedIn || userHasPremiumAccount; // true
// // // userLoggedIn || userHasMegaPremiumAccount; // true

// // // !userLoggedIn; // false
// // // !userHasMegaPremiumAccount; // true

// // let userLoggedIn = true;
// // let welcomeMessage = ''; // déclarer la variable ici

// // if (userLoggedIn) {
// //     welcomeMessage = 'Welcome back!'; // modifier la variable extérieure
// // } else {
// //     welcomeMessage = 'Welcome new user!'; // modifier la variable extérieure
// // }

// // console.log(welcomeMessage); // imprime 'Welcome back!'







// /////////////////////////////////////////////////////////////////////switch////////////////////////////////

// let firstUser = {
//     name: "Will Alexander",
//     age: 33,
//     accountLevel: "normal"
// };

// let secondUser = {
//     name: "Sarah Kate",
//     age: 21,
//     accountLevel: "premium"
// };

// let thirdUser = {
//     name: "Audrey Simon",
//     age: 27,
//     accountLevel: "mega-premium"
// };


// switch (firstUser.accountLevel) {
//     case 'normal':
//           console.log('You have a normal account!');
    
//     break;
//     case 'premium':
//           console.log('You have a premium account!');
    
//     break;
//     case 'mega-premium':
//           console.log('You have a mega premium account!');
//     break;
    
//     default:
//           console.log('Unknown account type!');
//     }


//     OR WITH IF ELSE CONDITion   ///////////

//     if (firstUser.accountLevel === 'normal' ) {
//               console.log('You have a normal account!');
//         } else if (firstUser.accountLevel === 'premium' ) {
//               console.log('You have a premium account!');
//         } else if (firstUser.accountLevel === 'mega-premium' ) {
//               console.log('You have a mega premium account!');
//         }  else {
//               console.log('Unknown account type!');
//         }



///////////////////ffffffffoorrrr//////////////
// const numberOfPassengers = 10;
// for (let i = 0; i < numberOfPassengers; i++) {
//    console.log("Passager embarqué !");
// }
// 
// div.class name you will get <div class=''> </div> automaticly


